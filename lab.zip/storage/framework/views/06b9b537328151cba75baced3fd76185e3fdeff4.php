

<?php $__env->startSection('content'); ?>

  <div class="container">

   
    <div class="row">
        <div class="col">
            <div class="jumbotron jumbotron-fluid">
                <div class="container">
                  <h1 class="display-6">نتائج التحليل</h1>
                  <?php if($results->count() != 1): ?>
                  <a href="<?php echo e(route('result.create')); ?>" class="btn btn-success">رفع صورة نتيجة التحليل</a>
                  <?php endif; ?>
                  

                </div>
              </div>
        </div>
    </div>

    <?php if($results->count() > 0): ?>
    <table class="table table-striped">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">صورة نتيجة التحليل</th>
            <th scope="col">تاريخ الرفع</th>

            <th scope="col">حذف الصورة</th>

          </tr>
        </thead>
        <tbody>
          <?php
              $results_count = 1;
          ?>
            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($results_count++); ?></th>
                <td><img src="<?php echo e(URL::asset($item->res_photo)); ?>" alt="<?php echo e($item->res_photo); ?>" class="img-thumbnail" width="100"></td>
                <td><?php echo e($item->created_at->diffForhumans()); ?></td>
                <td>
                    
                    
                    <?php if($item->user_id == Auth::id()): ?>
                    <a class="btn btn-danger" href="<?php echo e(route('result.destroy', ['id'=> $item->id])); ?>"><i class="far fa-trash-alt"></i></a>
   
                    <?php endif; ?>                    
                </td>
              </tr> 

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </tbody>
      </table>


    <?php else: ?>

    <div class="col">
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            لا توجد نتائج للتحيلات!
            
         </div>
    </div>
        
    <?php endif; ?>


    


  </div>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\majillano_soft\lab\resources\views/results/index.blade.php ENDPATH**/ ?>