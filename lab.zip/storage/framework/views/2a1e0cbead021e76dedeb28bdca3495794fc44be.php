

<?php $__env->startSection('content'); ?>

  <div class="container">

   
    <div class="row">
        <div class="col">
            <div class="jumbotron jumbotron-fluid">
                <div class="container">
                  <h1 class="display-6">كل المقالات</h1>
                  <a href="<?php echo e(route('post.create')); ?>" class="btn btn-success">مقال جديد</a>
                  <a href="<?php echo e(route('posts.trashed')); ?>" class="btn btn-danger">سلة المحذوفات</a>
                </div>
              </div>
        </div>
    </div>
<div class="row">
  <div class="col">
    <?php if($posts->count() > 0): ?>
    <table class="table table-striped">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">عنوان المقال</th>
            <th scope="col">كتب بواسطة</th>
            <th scope="col">صورة المقال</th>
            <th scope="col">التاريخ</th>
            <th scope="col">حذف</th>
          </tr>
        </thead>
        <tbody>
          <?php
              $posts_count = 1;
          ?>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($posts_count++); ?></th>
                <td><?php echo e($item->title); ?></td>
                <td><?php echo e($item->user->name); ?></td>
                <td><img src="<?php echo e(URL::asset($item->photo)); ?>" alt="<?php echo e($item->photo); ?>" class="img-thumbnail" width="100"></td>
                <td><?php echo e($item->created_at->diffForhumans()); ?></td>
                <td>
                    
                    
                    <?php if($item->user_id == Auth::id()): ?>
                    <a class="btn btn-danger" href="<?php echo e(route('post.destroy', ['id'=> $item->id])); ?>"><i class="far fa-trash-alt"></i></a>
   
                    <?php endif; ?>                    
                </td>
              </tr> 

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </tbody>
      </table>


    <?php else: ?>

  </div>
</div>
   
    <div class="col">
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            لا توجد مقالات!
            
         </div>
    </div>
        
    <?php endif; ?>


    


  </div>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\majillano_soft\lab\resources\views/posts/index.blade.php ENDPATH**/ ?>