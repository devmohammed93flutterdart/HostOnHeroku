

<?php $__env->startSection('content'); ?>

  <div class="container">

   
    <div class="row">
        <div class="col">
            <div class="jumbotron jumbotron-fluid">
                <div class="container">
                  <h1 class="display-6">Trashed Posts</h1>
                  <a href="<?php echo e(route('posts')); ?>" class="btn btn-success">All Post</a>
                </div>
              </div>
        </div>
    </div>

    <?php if($posts->count() > 0): ?>
    <table class="table table-striped">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Post Title</th>
            <th scope="col">Author</th>
            <th scope="col">Post Image</th>
            <th scope="col">Date</th>
            <th scope="col">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php
              $posts_count = 1;
          ?>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($posts_count++); ?></th>
                <td><?php echo e($item->title); ?></td>
                <td><?php echo e($item->user->name); ?></td>
                <td><img src="<?php echo e(URL::asset($item->photo)); ?>" alt="<?php echo e($item->photo); ?>" class="img-thumbnail" width="100"></td>
                <td><?php echo e($item->created_at->diffForhumans()); ?></td>
                <td>
                    
                    
                    <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#exampleModal">
                        <i class="far fa-trash-alt"></i>
                      </button>                    
                </td>
              </tr> 

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </tbody>
      </table>


    <?php else: ?>

    <div class="col">
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            No Posts in Trash!
            
         </div>
    </div>
        
    <?php endif; ?>


    


  </div>

<!-- delete Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">delete permanently</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            Do you want to delete permanently?
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
          <a href="<?php echo e(route('post.hdelete', ['id'=> $item->id])); ?>" type="button" class="btn btn-danger">Yes</a>
        </div>
      </div>
    </div>
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\majillano_soft\lab\resources\views/posts/trashed.blade.php ENDPATH**/ ?>